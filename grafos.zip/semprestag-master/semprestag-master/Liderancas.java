public class Liderancas<TIPO> {
    private Double peso;
    private Funcionarios<TIPO> inicio;
    private Funcionarios<TIPO> fim;

    public Liderancas(Double peso, Funcionarios<TIPO> inicio, Funcionarios<TIPO> fim) {
        this.peso = peso;
        this.inicio = inicio;
        this.fim = fim;
    }

    // Getters e Setter genéricos
    public Double getPeso() {return peso;}
    public void setPeso(Double peso) {this.peso = peso;}
    public Funcionarios<TIPO> getInicio() {return inicio;}
    public void setInicio(Funcionarios<TIPO> inicio) {this.inicio = inicio;}
    public Funcionarios<TIPO> getFim() {return fim;}
    public void setFim(Funcionarios<TIPO> fim) {this.fim = fim;}
}