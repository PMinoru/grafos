import java.util.ArrayList;

//cria as classes e definindo as variaveis
public class Empresa<TIPO> {
    private ArrayList<Funcionarios<TIPO>> funcionarios;
    private ArrayList<Liderancas<TIPO>> liderancas;

    // cria um objeto empresa, armazenando os funcionarios e lideranças, criando uma
    // arvore
    public Empresa() {
        this.funcionarios = new ArrayList<Funcionarios<TIPO>>();
        this.liderancas = new ArrayList<Liderancas<TIPO>>();
    }

    // metodo para adicionar um funcionario novo na empresa
    public void adicionarFuncionario(TIPO dado) {
        Funcionarios<TIPO> novoFuncionario = new Funcionarios<TIPO>(dado);
        this.funcionarios.add(novoFuncionario);
    }

    // getter de funcionario
    public Funcionarios<TIPO> getFuncionario(TIPO dado) {
        // transforma de generico para string
        String nomeBuscado = dado.toString().trim();
        // loop para percorrer todos os funcionairos (size pq é array)
        for (int i = 0; i < this.funcionarios.size(); i++) {
            String nomeAtual = this.funcionarios.get(i).getDado().toString().trim();
            if (nomeAtual.equalsIgnoreCase(nomeBuscado)) {
                return this.funcionarios.get(i);
            }
        }
        return null;
    }

    // metodo para adicionar uma nova liderança, sempre de cima para baixo
    public void adicionarLideranca(Double peso, TIPO dadoInicio, TIPO dadoFim) {
        Funcionarios<TIPO> inicio = this.getFuncionario(dadoInicio);
        Funcionarios<TIPO> fim = this.getFuncionario(dadoFim);

        // se o getter da classe funcionarios nao encontrar nada, ele vai dar nulo,
        // dando erro
        if (inicio == null || fim == null) {
            System.out.println("Erro ao criar liderança: Funcionário não encontrado.");
            return;
        }

        // apos a verificacao, cria
        Liderancas<TIPO> lideranca = new Liderancas<TIPO>(peso, inicio, fim);

        // adiciona a liderança que acabamos de passar os parametos no array de
        // lideranças
        this.liderancas.add(lideranca);
    }

    public void listarTodosFuncionarios() {
        System.out.println("\n--- Lista de Todos os Funcionários ---");
        // para cada objeto da classe funcionarios (apelidada de f)
        for (Funcionarios<TIPO> f : funcionarios) {
            // utiliza do get da classe de funcionarios para puxar todos os objetos
            System.out.println("- " + f.getDado());
        }
    }

    public void buscarSuperior(TIPO nomeFuncionario) {
        boolean encontrou = false;
        String nomeBuscado = nomeFuncionario.toString().trim();

        // Varre a lista global de lideranças da empresa
        for (Liderancas<TIPO> ligacao : this.liderancas) {
            String nomeLiderado = ligacao.getFim().getDado().toString().trim();

            if (nomeLiderado.equalsIgnoreCase(nomeBuscado)) {
                System.out.println("\nO superior direto de " + ligacao.getFim().getDado() + " é: "
                        + ligacao.getInicio().getDado());
                encontrou = true;
            }
        }

        if (!encontrou) {
            System.out.println(
                    "\nNenhum superior encontrado para: " + nomeFuncionario + " (Verifique se o nome está correto).");
        }
    }

// Método que vai puxar todos os subordinados de um funcionário (tanto os diretos quanto os indiretos, em cascata)
    public void buscarTodosSubordinados(TIPO nomeLider) {
        
        // Usa o método de busca da Empresa para tentar achar o objeto do funcionário pelo nome digitado
        Funcionarios<TIPO> lider = getFuncionario(nomeLider);

        // Se o método de busca não achar o funcionário, retorna null. Esse 'if' barra a execução para o sistema não dar erro fatal.
        if (lider == null) {
            System.out.println("\nFuncionário não encontrado. Verifique a ortografia.");
            return;
        }

        System.out.println("\n--- Subordinados de " + lider.getDado() + " ---");

        // Cria duas listas para controlar a busca na árvore da empresa (Algoritmo de Busca em Largura)
        // 'fila' dita quem será investigado agora; 'marcados' anota quem já foi visto para evitar repetições ou loops infinitos
        ArrayList<Funcionarios<TIPO>> fila = new ArrayList<Funcionarios<TIPO>>();
        ArrayList<Funcionarios<TIPO>> marcados = new ArrayList<Funcionarios<TIPO>>();

        // Coloca o líder pesquisado nas listas para dar o pontapé inicial na busca
        fila.add(lider);
        marcados.add(lider);
        
        // Variável simples para sabermos se imprimimos alguém ou se ele não lidera ninguém
        boolean temSubordinados = false;

        // O loop vai rodar sem parar enquanto houver funcionários na fila esperando para terem seus subordinados investigados
        while (fila.size() > 0) {
            
            // Tira o primeiro funcionário da fila (remove do índice 0) e define ele como o alvo 'atual' da investigação
            Funcionarios<TIPO> atual = fila.remove(0);

            // Varre o array global de lideranças (todas as conexões da empresa) procurando quem está ligado a esse funcionário 'atual'
            for (int i = 0; i < this.liderancas.size(); i++) {
                
                // Pega a ligação da posição 'i' para analisarmos
                Liderancas<TIPO> ligacao = this.liderancas.get(i);

                // Se o funcionário alvo da investigação for o superior (início) dessa ligação específica, achamos um subordinado!
                if (ligacao.getInicio().equals(atual)) {
                    
                    // Pega o subordinado que está na ponta final dessa ligação
                    Funcionarios<TIPO> subordinado = ligacao.getFim();

                    // Verifica se já listamos esse subordinado antes (se não estiver nos marcados, entra no if)
                    if (!marcados.contains(subordinado)) {
                        
                        // Marca ele como visto, imprime o nome na tela e anota que achamos pelo menos um subordinado
                        marcados.add(subordinado);
                        System.out.println("- " + subordinado.getDado());
                        temSubordinados = true;
                        
                        // ESSENCIAL: Coloca esse subordinado na 'fila' para que, nos próximos giros do while, o código procure os subordinados DELE também (busca em cascata)
                        fila.add(subordinado); 
                    }
                }
            }
        }

        // Se o while terminar e essa variável continuar 'false', significa que o if lá de dentro nunca foi acionado
        if (!temSubordinados) {
            System.out.println("Este funcionário não possui subordinados.");
        }
    }
}