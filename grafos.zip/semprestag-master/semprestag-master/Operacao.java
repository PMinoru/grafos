import java.util.Scanner;

public class Operacao {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Empresa<String> organograma = new Empresa<String>();
        
        // Adicionando nomes reais (Cargo entre parênteses para contexto)
        organograma.adicionarFuncionario("Roberto (CEO)");
        organograma.adicionarFuncionario("Camila (Diretora de TI)");
        organograma.adicionarFuncionario("Samyr (Diretor de RH)");
        organograma.adicionarFuncionario("Pedro (Gerente Back-End)");
        organograma.adicionarFuncionario("Lucas (Senior)");
        organograma.adicionarFuncionario("Mariana (Pleno)");
        organograma.adicionarFuncionario("Joao (Junior)");

        // Adicionando as lideranças usando os nomes exatos declarados acima
        organograma.adicionarLideranca(1.0, "Roberto (CEO)", "Camila (Diretora de TI)");
        organograma.adicionarLideranca(1.0, "Roberto (CEO)", "Samyr (Diretor de RH)");
        organograma.adicionarLideranca(1.0, "Camila (Diretora de TI)", "Pedro (Gerente Back-End)");
        organograma.adicionarLideranca(1.0, "Pedro (Gerente Back-End)", "Lucas (Senior)");
        organograma.adicionarLideranca(1.0, "Lucas (Senior)", "Mariana (Pleno)");
        organograma.adicionarLideranca(1.0, "Mariana (Pleno)", "Joao (Junior)");

        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n=======================================");
            System.out.println("        SISTEMA SEMPRESTAG             ");
            System.out.println("=======================================");
            System.out.println("Digite 1 para visualizar todos os funcionarios");
            System.out.println("Digite 2 para procurar o superior de um funcionário");
            System.out.println("Digite 3 para procurar os subordinados de um funcionário");
            System.out.println("Digite 0 para sair do sistema");
            System.out.print("Escolha uma opção: ");
            
            // Tratamento básico caso o usuário digite letra onde deveria ser número
            if (scanner.hasNextInt()) {
                opcao = scanner.nextInt();
                scanner.nextLine(); // Consome a quebra de linha
            } else {
                System.out.println("Por favor, digite um número válido.");
                scanner.nextLine(); // Limpa o buffer de erro
                continue;
            }

            switch (opcao) {
                case 1:
                    organograma.listarTodosFuncionarios();
                    break;
                
                case 2:
                    System.out.print("Digite o nome do funcionário (ex: Lucas (Senior)): ");
                    String nomeParaSuperior = scanner.nextLine();
                    organograma.buscarSuperior(nomeParaSuperior);
                    break;
                
                case 3:
                    System.out.print("Digite o nome do funcionário (ex: Camila (Diretora de TI)): ");
                    String nomeParaSubordinados = scanner.nextLine();
                    organograma.buscarTodosSubordinados(nomeParaSubordinados);
                    break;
                
                case 0:
                    System.out.println("Encerrando o sistema...");
                    break;
                
                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }
        }
        
        scanner.close();
    }
}