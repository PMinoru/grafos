public class Funcionarios<TIPO> {
    private TIPO dado;

    // Cria um novo objeto funcionario
    // TIPO é para deixar o tipo de dado genérico, podendo ser String, int, etc...
    public Funcionarios(TIPO valor) {
        this.dado = valor;
    }

    //Getters e Setters
    //Puxar informações de um funcionário
    public TIPO getDado() {return dado;}
    //Setar valores do funcionario
    public void setDado(TIPO dado) {this.dado = dado;}
}